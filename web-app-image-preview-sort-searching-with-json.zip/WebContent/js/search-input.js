/**
 * 
 */
function SearchInput(searchText){
	this.searchText=searchText;
	this.show=function(){
		console.log(this.searchText);
	}
}